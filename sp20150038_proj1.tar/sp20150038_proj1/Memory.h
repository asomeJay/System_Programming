#ifndef __Memory_H__
#define __Memory_H__

char memory[1 << 20];

void dump(int , int, int );
void dump2(int, int);

void edit(int, int);
void fill(int, int, int);
void reset();
#endif
